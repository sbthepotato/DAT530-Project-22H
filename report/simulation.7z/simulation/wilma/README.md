# Wilma model results

To run this model simply open `wilma.m` and run it (assuming you have GPenSIM10 and MATLAB). The logic is partially explained in comments in the code.

## results

| run nr | time    |
|--------|---------|
| 1      | 261.5   |
| 2      | 242.5   |
| 3      | 262     |
| 4      | 225.5   |
| 5      | 269     |
| 6      | 250.5   |
| 7      | 243     |
| 8      | 253.5   |
| 9      | 279     |
| 10     | 245     |
| avg    | 253.15  |
| target | 253     |
