# Block model results

To run this model simply open `block.m` and run it (assuming you have GPenSIM10 and MATLAB). The logic is partially explained in comments in the code.

## results

| run nr | time    |
|--------|---------|
| 1      | 414     |
| 2      | 435     |
| 3      | 422.5   |
| 4      | 413.5   |
| 5      | 414.5   |
| 6      | 433     |
| 7      | 434     |
| 8      | 400     |
| 9      | 442.5   |
| 10     | 443     |
| avg    | 425.2   |
| target | 414     |
