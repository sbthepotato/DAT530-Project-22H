# Wilma-Block model results

To run this model simply open `wilmablock.m` and run it (assuming you have GPenSIM10 and MATLAB). The logic is partially explained in comments in the code.

## results

| run nr | time    |
|--------|---------|
| 1      | 289     |
| 2      | 313.5   |
| 3      | 307     |
| 4      | 289     |
| 5      | 322     |
| 6      | 306     |
| 7      | 301.5   |
| 8      | 320     |
| 9      | 294     |
| 10     | 295.5   |
| avg    | 303.72  |
| target | <253.15 |
